"""
Configuration module for the hypexbt Twitter bot.

This module handles loading and accessing configuration settings.
"""

import os
import logging
import json
from typing import Dict, Any, Optional
from pathlib import Path
from dotenv import load_dotenv

logger = logging.getLogger(__name__)


class Config:
    """
    Configuration class for the hypexbt Twitter bot.
    """

    def __init__(self, env_file: str = None):
        """
        Initialize the configuration.

        Args:
            env_file: Path to the .env file. If None, uses the default .env file.
        """
        # Load environment variables
        if env_file:
            load_dotenv(env_file)
        else:
            load_dotenv()

        # Initialize configuration
        self._init_config()

    def _init_config(self):
        """Initialize the configuration."""
        try:
            # Twitter API credentials
            self.twitter_credentials = {
                "api_key": os.getenv("X_API_KEY"),
                "api_secret": os.getenv("X_API_SECRET"),
                "bearer_token": os.getenv("X_BEARER_TOKEN"),
                "access_token": os.getenv("X_ACCESS_TOKEN"),
                "access_token_secret": os.getenv("X_ACCESS_TOKEN_SECRET"),
            }

            # API endpoints
            self.api_endpoints = {
                "hyperliquid": os.getenv("HL_API_URL", "https://api.hyperliquid.xyz"),
                "coingecko": os.getenv(
                    "COINGECKO_API", "https://api.coingecko.com/api/v3"
                ),
            }

            # Slack webhook for error reporting
            self.slack_webhook = os.getenv("SLACK_WEBHOOK")

            # Tweet scheduling configuration
            self.tweet_schedule = {
                "min_tweets_per_day": int(os.getenv("MIN_TWEETS_PER_DAY", "10")),
                "max_tweets_per_day": int(os.getenv("MAX_TWEETS_PER_DAY", "20")),
                "min_interval_minutes": int(os.getenv("MIN_INTERVAL_MINUTES", "30")),
                "max_interval_minutes": int(os.getenv("MAX_INTERVAL_MINUTES", "180")),
                "active_hours_start": int(os.getenv("ACTIVE_HOURS_START", "0")),
                "active_hours_end": int(os.getenv("ACTIVE_HOURS_END", "23")),
            }

            # Tweet content distribution
            self.tweet_distribution = {
                "hyperliquid_news": float(os.getenv("HYPERLIQUID_NEWS_PCT", "15"))
                / 100,
                "token_launches": float(os.getenv("TOKEN_LAUNCHES_PCT", "20")) / 100,
                "token_graduations": float(os.getenv("TOKEN_GRADUATIONS_PCT", "20"))
                / 100,
                "trading_signals": float(os.getenv("TRADING_SIGNALS_PCT", "15")) / 100,
                "daily_stats": float(os.getenv("DAILY_STATS_PCT", "15")) / 100,
                "token_fundamentals": float(os.getenv("TOKEN_FUNDAMENTALS_PCT", "15"))
                / 100,
            }

            # Validate configuration
            self._validate_config()

            logger.info("Configuration loaded successfully")

        except Exception as e:
            logger.error(f"Failed to initialize configuration: {str(e)}", exc_info=True)
            raise

    def _validate_config(self):
        """Validate the configuration."""
        # Check Twitter credentials
        for key, value in self.twitter_credentials.items():
            if not value:
                logger.warning(f"Twitter credential '{key}' is not set")

        # Check API endpoints
        for key, value in self.api_endpoints.items():
            if not value:
                logger.warning(f"API endpoint '{key}' is not set")

        # Check tweet distribution
        total_pct = sum(self.tweet_distribution.values())
        if abs(total_pct - 1.0) > 0.01:  # Allow for small floating point errors
            logger.warning(
                f"Tweet distribution percentages do not add up to 100% (got {total_pct * 100}%)"
            )

    def get_twitter_credentials(self) -> Dict[str, str]:
        """
        Get Twitter API credentials.

        Returns:
            A dictionary with Twitter API credentials.
        """
        return self.twitter_credentials

    def get_api_endpoints(self) -> Dict[str, str]:
        """
        Get API endpoints.

        Returns:
            A dictionary with API endpoints.
        """
        return self.api_endpoints

    def get_slack_webhook(self) -> Optional[str]:
        """
        Get Slack webhook URL.

        Returns:
            The Slack webhook URL, or None if not set.
        """
        return self.slack_webhook

    def get_tweet_schedule(self) -> Dict[str, int]:
        """
        Get tweet scheduling configuration.

        Returns:
            A dictionary with tweet scheduling configuration.
        """
        return self.tweet_schedule

    def get_tweet_distribution(self) -> Dict[str, float]:
        """
        Get tweet content distribution.

        Returns:
            A dictionary with tweet content distribution.
        """
        return self.tweet_distribution
