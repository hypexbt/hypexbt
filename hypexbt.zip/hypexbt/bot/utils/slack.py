"""
Slack notification module for the hypexbt Twitter bot.

This module handles sending notifications to Slack for error reporting.
"""

import logging
import json
from typing import Dict, Any, Optional
from datetime import datetime

import requests

from bot.utils.config import Config

logger = logging.getLogger(__name__)


class SlackNotifier:
    """
    Notifier for sending messages to Slack.
    """

    def __init__(self, config: Config):
        """
        Initialize the Slack notifier.

        Args:
            config: The configuration object.
        """
        self.config = config
        self.webhook_url = config.get_slack_webhook()

    def send_message(self, message: str, level: str = "info") -> bool:
        """
        Send a message to Slack.

        Args:
            message: The message to send.
            level: The message level (info, warning, error).

        Returns:
            True if the message was sent successfully, False otherwise.
        """
        if not self.webhook_url:
            logger.warning("Slack webhook URL not configured, skipping notification")
            return False

        try:
            # Set color based on level
            color = {
                "info": "#36a64f",  # green
                "warning": "#ffcc00",  # yellow
                "error": "#ff0000",  # red
            }.get(level.lower(), "#36a64f")

            # Create payload
            payload = {
                "attachments": [
                    {
                        "color": color,
                        "title": f"hypexbt Bot {level.capitalize()}",
                        "text": message,
                        "ts": int(datetime.now().timestamp()),
                    }
                ]
            }

            # Send message
            response = requests.post(
                self.webhook_url,
                data=json.dumps(payload),
                headers={"Content-Type": "application/json"},
            )

            response.raise_for_status()
            logger.info(f"Sent Slack notification: {message[:50]}...")
            return True

        except Exception as e:
            logger.error(f"Failed to send Slack notification: {str(e)}", exc_info=True)
            return False

    def send_error(self, error_message: str, details: Optional[str] = None) -> bool:
        """
        Send an error message to Slack.

        Args:
            error_message: The error message.
            details: Optional additional details.

        Returns:
            True if the message was sent successfully, False otherwise.
        """
        message = error_message
        if details:
            message += f"\n\nDetails:\n```{details}```"

        return self.send_message(message, level="error")
